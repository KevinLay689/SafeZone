package com.example.kevinlay.safezone;

/**
 * Created by kevinlay on 4/12/17.
 */

public class SafeZoneInfo {
    String lat,lng,name;

    public SafeZoneInfo(String lat, String lng, String name){
        this.lat = lat;
        this.lng = lng;
        this.name = name;
    }

}
