package com.example.kevinlay.safezone;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by kevinlay on 4/7/17.
 */
public class Report extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
